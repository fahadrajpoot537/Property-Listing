@extends('layouts.admin')

@section('content')
    <!-- Sticky Header & Step Indicator -->
    <div class="sticky top-0 z-30 bg-slate-50/95 backdrop-blur-md pt-3 pb-4 -mx-6 px-6 border-b border-slate-200/50 mb-6">
        <div class="max-w-7xl mx-auto">
            <div class="flex justify-between items-center mb-4">
                <div class="flex items-center gap-3">
                    <div
                        class="w-10 h-10 bg-[#131B31] text-white rounded-lg flex items-center justify-center text-lg shadow-lg">
                        <i class='bx bx-zap'></i>
                    </div>
                    <div>
                        <h3 class="text-lg font-black text-slate-900 tracking-tight" id="pageTitle">
                            {{ isset($listing) ? 'Edit Deal' : 'New Private Deal' }}
                        </h3>
                        <p class="text-[9px] text-slate-400 font-bold uppercase tracking-widest mt-0.5">
                            Private Stream • Step <span id="currentStepText" class="text-indigo-600">1</span> of 3
                        </p>
                    </div>
                </div>
                <a href="{{ route('admin.off-market-listings.index') }}"
                    class="w-9 h-9 flex items-center justify-center rounded-lg bg-white border border-slate-100 text-slate-400 hover:text-rose-500 transition-all shadow-sm">
                    <i class='bx bx-x text-xl'></i>
                </a>
            </div>

            <!-- Responsive Step Indicator -->
            <div class="relative flex items-center justify-between px-4 md:px-32">
                <div class="absolute top-1/2 left-0 w-full h-1 bg-slate-100 -translate-y-1/2 rounded-full">
                    <div id="stepLine" class="w-0 h-full bg-[#8046F1] transition-all duration-700">
                    </div>
                </div>
                @for($i = 1; $i <= 3; $i++)
                    <div class="relative z-10 flex flex-col items-center">
                        <div id="stepCircle{{$i}}"
                            class="w-8 h-8 rounded-lg bg-white border-2 border-slate-100 text-slate-400 flex items-center justify-center text-xs font-black shadow-sm transition-all">
                            {{$i}}
                        </div>
                    </div>
                @endfor
            </div>
        </div>
    </div>

    <div class="bg-white rounded-xl border border-slate-100 overflow-hidden mb-8 shadow-sm">
        <form id="listingForm" enctype="multipart/form-data" class="flex flex-col flex-1">
            @csrf
            @if(isset($listing))
                @method('PUT')
                <input type="hidden" id="listingId" name="id" value="{{ $listing->id }}">
            @else
                <input type="hidden" id="listingId" name="id">
            @endif

            <div class="px-6 py-6">
                <!-- Step 1: Mandatory Fields (Key Information) -->
                <div id="stage1" class="space-y-8 transition-all duration-500">
                    <div class="mb-6">
                        <h4 class="text-sm font-black text-slate-900 tracking-tight uppercase">Essential Information</h4>
                        <p class="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-0.5">Basic details for
                            private publication.</p>
                    </div>
                    <!-- SECTION 1: HEADER INFO -->
                    <div
                        class="grid grid-cols-1 md:grid-cols-12 gap-4 bg-slate-50/50 p-5 rounded-xl border border-slate-100">
                        <div class="md:col-span-8">
                            <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Deal
                                Headline</label>
                            <input type="text" name="property_title" id="property_title"
                                class="w-full rounded-lg border-slate-200 bg-white text-[13px] px-4 py-3 outline-none focus:border-indigo-400 transition-all font-medium placeholder:text-slate-300"
                                placeholder="e.g. Stunning 3 Bed Apartment with City Views" required
                                value="{{ $listing->property_title ?? '' }}">
                        </div>
                        <div class="md:col-span-4">
                            <label
                                class="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2">Internal
                                Ref</label>
                            <input type="text" name="property_reference_number"
                                class="w-full rounded-2xl border-slate-200 bg-white text-sm p-4 focus:ring-4 focus:ring-indigo-50 transition-all font-mono text-indigo-600"
                                placeholder="AUTO-GEN-REF" value="{{ $listing->property_reference_number ?? '' }}">
                        </div>

                        <div class="md:col-span-12 grid grid-cols-1 md:grid-cols-3 gap-6 mt-2">
                            <div class="md:col-span-2">
                                <label
                                    class="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2">Property
                                    Address (Search via Google)</label>
                                <div class="relative group">
                                    <i
                                        class='bx bx-map absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 text-lg group-focus-within:text-indigo-500 transition-colors'></i>
                                    <input type="text" name="address" id="address"
                                        class="w-full rounded-2xl border-slate-200 bg-white text-sm p-4 pl-12 focus:ring-4 focus:ring-indigo-50 transition-all font-medium"
                                        placeholder="Start typing area or postcode..." required
                                        value="{{ $listing->address ?? '' }}">
                                    <input type="hidden" name="latitude" id="latitude"
                                        value="{{ $listing->latitude ?? '' }}">
                                    <input type="hidden" name="longitude" id="longitude"
                                        value="{{ $listing->longitude ?? '' }}">
                                </div>
                            </div>
                            <div>
                                <label
                                    class="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2">Postcode</label>
                                <input type="text" name="postcode" id="postcode"
                                    class="w-full rounded-2xl border-slate-200 bg-white text-sm p-4 focus:ring-4 focus:ring-indigo-50 transition-all font-bold text-slate-700"
                                    placeholder="e.g. E14 9GE" required value="{{ $listing->postcode ?? '' }}">
                            </div>
                            <div class="md:col-span-3">
                                <label
                                    class="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2">Display
                                    Address (Masked/Public)</label>
                                <input type="text" name="display_address" id="display_address"
                                    class="w-full rounded-2xl border-slate-200 bg-white text-sm p-4 focus:ring-4 focus:ring-indigo-50 transition-all font-medium"
                                    placeholder="e.g. Canary Wharf, London" required
                                    value="{{ $listing->display_address ?? '' }}">
                            </div>
                        </div>
                    </div>

                    <!-- SECTION 2: PRICING & PURPOSE -->
                    <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
                        <div class="md:col-span-4">
                            <h4
                                class="text-xs font-black text-slate-900 uppercase tracking-widest flex items-center gap-2 mb-4">
                                <span
                                    class="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center text-lg"><i
                                        class='bx bx-pound'></i></span>
                                Pricing & Purpose
                            </h4>
                        </div>

                        <div class="space-y-2">
                            <label class="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Listing
                                Purpose</label>
                            <select name="purpose" id="purpose" class="select2 w-full" required>
                                <option value="Buy" {{ (isset($listing) && $listing->purpose == 'Buy') ? 'selected' : '' }}>
                                    For Sale (Fixed/Guide)</option>
                                <option value="Rent" {{ (isset($listing) && $listing->purpose == 'Rent') ? 'selected' : '' }}>
                                    To Rent / Lease</option>
                            </select>
                        </div>

                        <div class="space-y-2">
                            <label class="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Listing
                                Price (£)</label>
                            <div class="relative">
                                <span class="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold">£</span>
                                <input type="text" name="price"
                                    class="w-full rounded-2xl border-slate-200 bg-white text-sm p-4 pl-8 focus:ring-4 focus:ring-emerald-50 transition-all font-black text-slate-800"
                                    placeholder="0,000" required value="{{ $listing->price ?? '' }}">
                            </div>
                        </div>

                        <div class="space-y-2">
                            <label class="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Price
                                Qualifier</label>
                            <select name="price_qualifier" class="select2 w-full" required>
                                @foreach(['Offers in Excess Of', 'Guide Price', 'Fixed Price', 'POA', 'Under Offer', 'Sold STC'] as $pq)
                                    <option value="{{ $pq }}" {{ (isset($listing) && $listing->price_qualifier == $pq) ? 'selected' : '' }}>{{ $pq }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div id="rent_fields_container"
                            class="{{ (isset($listing) && $listing->purpose == 'Rent') ? '' : 'hidden' }} md:col-span-4 grid grid-cols-1 md:grid-cols-2 gap-6 p-6 bg-slate-50 rounded-3xl border border-slate-100 mt-2">
                            <div class="space-y-2">
                                <label class="block text-[10px] font-black text-indigo-400 uppercase tracking-[0.2em]">Rent
                                    Frequency</label>
                                <select name="rent_frequency" class="select2 w-full">
                                    <option value="pcm" {{ (isset($listing) && $listing->rent_frequency == 'pcm') ? 'selected' : '' }}>Per Calendar Month (PCM)</option>
                                    <option value="pw" {{ (isset($listing) && $listing->rent_frequency == 'pw') ? 'selected' : '' }}>Per Week (PW)</option>
                                </select>
                            </div>
                            <div class="space-y-2">
                                <label
                                    class="block text-[10px] font-black text-indigo-400 uppercase tracking-[0.2em]">Security
                                    Deposit (£)</label>
                                <div class="relative">
                                    <span class="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold">£</span>
                                    <input type="text" name="deposit"
                                        class="w-full rounded-2xl border-slate-200 bg-white text-sm p-4 pl-8 focus:ring-4 focus:ring-indigo-50 transition-all font-bold"
                                        placeholder="5-week deposit equiv." value="{{ $listing->details->deposit ?? '' }}">
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- SECTION 3: KEY SPECIFICATIONS -->
                    <div class="grid grid-cols-2 md:grid-cols-5 gap-4 md:gap-6">
                        <div class="md:col-span-5 border-t border-slate-100 pt-8 mt-4">
                            <h4
                                class="text-xs font-black text-slate-900 uppercase tracking-widest flex items-center gap-2 mb-6">
                                <span
                                    class="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center text-lg"><i
                                        class='bx bx-cube-alt'></i></span>
                                Core Specifications
                            </h4>
                        </div>

                        <div id="bedrooms_container"
                            class="bg-indigo-50/30 p-5 rounded-3xl border border-indigo-100/50 hover:shadow-lg hover:shadow-indigo-500/5 transition-all group">
                            <label
                                class="block text-[9px] font-black text-indigo-400 uppercase tracking-widest mb-2 group-hover:text-indigo-600">Bedrooms</label>
                            <div class="flex items-center gap-3">
                                <i class='bx bx-door-open text-2xl text-indigo-500'></i>
                                <select name="bedrooms" id="bedrooms"
                                    class="w-full bg-transparent border-0 p-0 focus:ring-0 text-xl font-black text-slate-800 appearance-none cursor-pointer"
                                    required>
                                    <option value="Studio" {{ (isset($listing) && $listing->bedrooms == 'Studio') ? 'selected' : '' }}>Studio</option>
                                    @for($i = 1; $i <= 9; $i++)
                                        <option value="{{ $i }}" {{ (isset($listing) && $listing->bedrooms == $i) ? 'selected' : '' }}>{{ $i }}</option>
                                    @endfor
                                    <option value="10+" {{ (isset($listing) && $listing->bedrooms == '10+') ? 'selected' : '' }}>10+</option>
                                </select>
                            </div>
                        </div>

                        <div id="bathrooms_container"
                            class="bg-emerald-50/30 p-5 rounded-3xl border border-emerald-100/50 hover:shadow-lg hover:shadow-emerald-500/5 transition-all group">
                            <label
                                class="block text-[9px] font-black text-emerald-400 uppercase tracking-widest mb-2 group-hover:text-emerald-600">Bathrooms</label>
                            <div class="flex items-center gap-3">
                                <i class='bx bx-bath text-2xl text-emerald-500'></i>
                                <select name="bathrooms" id="bathrooms"
                                    class="w-full bg-transparent border-0 p-0 focus:ring-0 text-xl font-black text-slate-800 appearance-none cursor-pointer">
                                    @for($i = 1; $i <= 9; $i++)
                                        <option value="{{ $i }}" {{ (isset($listing) && $listing->bathrooms == $i) ? 'selected' : '' }}>{{ $i }}</option>
                                    @endfor
                                    <option value="10+" {{ (isset($listing) && $listing->bathrooms == '10+') ? 'selected' : '' }}>10+</option>
                                </select>
                            </div>
                        </div>

                        <div id="receptions_container"
                            class="bg-amber-50/30 p-5 rounded-3xl border border-amber-100/50 hover:shadow-lg hover:shadow-amber-500/5 transition-all group">
                            <label
                                class="block text-[9px] font-black text-amber-500 uppercase tracking-widest mb-2 group-hover:text-amber-600">Reception
                                Rooms</label>
                            <div class="flex items-center gap-3">
                                <i class='bx bx-chair text-2xl text-amber-500'></i>
                                <input type="text" name="reception_rooms" id="reception_rooms"
                                    class="w-full bg-transparent border-0 p-0 focus:ring-0 text-xl font-black text-slate-800"
                                    value="{{ $listing->reception_rooms ?? 0 }}">
                            </div>
                        </div>

                        <div
                            class="bg-rose-50/30 p-5 rounded-3xl border border-rose-100/50 hover:shadow-lg hover:shadow-rose-500/5 transition-all group">
                            <label
                                class="block text-[9px] font-black text-rose-400 uppercase tracking-widest mb-2 group-hover:text-rose-600">Floor
                                Area (SqFt)</label>
                            <div class="flex items-center gap-3">
                                <i class='bx bx-area text-2xl text-rose-500'></i>
                                <input type="text" name="area_size"
                                    class="w-full bg-transparent border-0 p-0 focus:ring-0 text-xl font-black text-slate-800"
                                    value="{{ $listing->area_size ?? '' }}">
                            </div>
                        </div>

                        <div
                            class="bg-purple-50/30 p-5 rounded-3xl border border-purple-100/50 hover:shadow-lg hover:shadow-purple-500/5 transition-all group">
                            <label
                                class="block text-[9px] font-black text-purple-400 uppercase tracking-widest mb-2 group-hover:text-purple-600">Floor
                                Level</label>
                            <div class="flex items-center gap-3">
                                <i class='bx bx-buildings text-2xl text-purple-500'></i>
                                <input type="text" name="floor_level"
                                    class="w-full bg-transparent border-0 p-0 focus:ring-0 text-xl font-black text-slate-800"
                                    placeholder="G, 1st, 2nd..." value="{{ $listing->floor_level ?? '' }}">
                            </div>
                        </div>
                    </div>

                    <!-- SECTION 4: TYPES & CATEGORIZATION -->
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 pt-6">
                        <div class="space-y-2">
                            <label class="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Listing
                                Type</label>
                            <select name="property_type_id" id="property_type_id" class="select2 w-full" required
                                onchange="handleTypeChange()">
                                <option value="">Select Portfolio Type</option>
                                @foreach($propertyTypes as $type)
                                    <option value="{{ $type->id }}" data-title="{{ strtolower($type->title) }}" {{ (isset($listing) && $listing->property_type_id == $type->id) ? 'selected' : '' }}>
                                        {{ $type->title }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="space-y-2">
                            <label class="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Strategy
                                Category</label>
                            <select name="unit_type_id" id="unit_type_id" class="select2 w-full" required
                                data-selected="{{ $listing->unit_type_id ?? '' }}">
                                <option value="">Choose Category</option>
                            </select>
                        </div>
                        <input type="hidden" name="sub_type" value="Not Specified">
                    </div>

                    <!-- SECTION 5: DESCRIPTIONS -->
                    <div class="space-y-8 pt-6">
                        <div>
                            <label
                                class="block text-[10px] font-black text-indigo-400 uppercase tracking-[0.2em] mb-3">Elevator
                                Pitch (Summary Overview)</label>
                            <textarea name="summary_description" maxlength="300"
                                class="w-full rounded-2xl border-slate-200 bg-white text-sm p-4 focus:ring-4 focus:ring-indigo-50 transition-all font-medium min-h-[100px]"
                                placeholder="The 'hook' for the property... Max 300 characters.">{{ $listing->summary_description ?? '' }}</textarea>
                        </div>

                        <div>
                            <label
                                class="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-3">Detailed
                                Narrative</label>
                            <textarea id="description_editor"
                                class="w-full rounded-2xl text-sm p-4 min-h-[300px]">{{ $listing->description ?? '' }}</textarea>
                            <input type="hidden" name="description" id="description_hidden"
                                value="{{ $listing->description ?? '' }}">
                        </div>
                    </div>
                </div>

                <!-- Step 2: In-Depth Property Details -->
                <div id="stage2" class="hidden space-y-12 transition-all duration-500">
                    <!-- Key Investment Features -->
                    <div class="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
                        <label
                            class="block text-xs font-black text-slate-900 uppercase tracking-widest mb-6 flex items-center gap-3">
                            <span
                                class="w-10 h-10 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center text-xl"><i
                                    class='bx bx-star'></i></span>
                            Key Performance Indicators & Features
                        </label>
                        <div id="key_features_container" class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            @if(isset($listing->details) && $listing->details->key_features)
                                @foreach($listing->details->key_features as $feature)
                                    <div
                                        class="flex items-center gap-3 p-1 bg-slate-50 rounded-2xl group transition-all hover:bg-white hover:shadow-md border border-transparent hover:border-slate-100">
                                        <div
                                            class="w-8 h-8 rounded-xl bg-white flex items-center justify-center text-slate-400 shadow-sm">
                                            <i class='bx bx-check-circle'></i>
                                        </div>
                                        <input type="text" name="key_features[]"
                                            class="flex-1 bg-transparent border-0 text-sm font-medium focus:ring-0 p-2"
                                            value="{{ $feature }}">
                                        <button type="button" onclick="this.parentElement.remove()"
                                            class="p-3 text-rose-400 hover:text-rose-600 transition-colors opacity-0 group-hover:opacity-100 hover:bg-rose-50 rounded-xl">
                                            <i class='bx bx-trash'></i>
                                        </button>
                                    </div>
                                @endforeach
                            @endif
                        </div>
                        <button type="button" onclick="addKeyFeature()"
                            class="mt-6 flex items-center gap-2 px-6 py-3 rounded-2xl bg-indigo-50 text-indigo-600 text-[10px] font-black uppercase tracking-widest hover:bg-indigo-100 transition-all border border-indigo-100">
                            <i class='bx bx-plus-circle text-lg'></i> Append New Feature
                        </button>
                    </div>

                    <!-- Material & Structural Info -->
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                        <div class="md:col-span-3">
                            <h4 class="text-xs font-black text-slate-900 uppercase tracking-widest flex items-center gap-2">
                                <span
                                    class="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center text-lg"><i
                                        class='bx bx-info-circle'></i></span>
                                Material & Legal Information
                            </h4>
                        </div>

                        <div class="space-y-4 p-6 bg-slate-50/50 rounded-3xl border border-slate-100">
                            <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Ownership
                                Tenure</label>
                            <select name="tenure" id="tenure" class="select2 w-full" onchange="toggleLeaseholdFields()">
                                <option value="Freehold" {{ (isset($listing->materialInfo) && $listing->materialInfo->tenure == 'Freehold') ? 'selected' : '' }}>Freehold / Outright
                                </option>
                                <option value="Leasehold" {{ (isset($listing->materialInfo) && $listing->materialInfo->tenure == 'Leasehold') ? 'selected' : '' }}>Leasehold / Rental
                                </option>
                                <option value="Share of Freehold" {{ (isset($listing->materialInfo) && $listing->materialInfo->tenure == 'Share of Freehold') ? 'selected' : '' }}>Share of
                                    Freehold</option>
                                <option value="Commonhold" {{ (isset($listing->materialInfo) && $listing->materialInfo->tenure == 'Commonhold') ? 'selected' : '' }}>Commonhold</option>
                            </select>

                            <div id="leasehold_fields"
                                class="{{ (isset($listing->materialInfo) && $listing->materialInfo->tenure == 'Leasehold') ? '' : 'hidden' }} space-y-4 pt-4 border-t border-slate-200">
                                <div>
                                    <label class="block text-[9px] font-black text-indigo-500 uppercase mb-1">Unexpired Term
                                        (Years)</label>
                                    <input type="text" name="unexpired_years"
                                        class="w-full rounded-xl border-slate-200 bg-white p-3 text-sm font-bold"
                                        value="{{ $listing->materialInfo->unexpired_years ?? '' }}">
                                </div>
                                <div class="grid grid-cols-2 gap-3">
                                    <div>
                                        <label class="block text-[9px] font-black text-indigo-500 uppercase mb-1">G. Rent
                                            (£)</label>
                                        <input type="text" name="ground_rent"
                                            class="w-full rounded-xl border-slate-200 bg-white p-3 text-sm font-bold"
                                            value="{{ $listing->materialInfo->ground_rent ?? '' }}">
                                    </div>
                                    <div>
                                        <label class="block text-[9px] font-black text-indigo-500 uppercase mb-1">Service
                                            (£)</label>
                                        <input type="text" name="service_charge"
                                            class="w-full rounded-xl border-slate-200 bg-white p-3 text-sm font-bold"
                                            value="{{ $listing->materialInfo->service_charge ?? '' }}">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="md:col-span-2 space-y-6">
                            <div class="grid grid-cols-2 gap-6 p-6 bg-slate-50/50 rounded-3xl border border-slate-100">
                                <div class="space-y-2">
                                    <label class="block text-[10px] font-black text-slate-400 uppercase">Parking
                                        Availability</label>
                                    <input type="text" name="parking_type"
                                        class="w-full rounded-xl border-slate-200 bg-white p-3 text-sm font-medium"
                                        placeholder="e.g. Allocated, Gated..."
                                        value="{{ $listing->materialInfo->parking_type ?? '' }}">
                                </div>
                                <div class="space-y-2">
                                    <label class="block text-[10px] font-black text-slate-400 uppercase">Parking
                                        Count</label>
                                    <input type="text" name="parking_spaces_count"
                                        class="w-full rounded-xl border-slate-200 bg-white p-3 text-sm font-black"
                                        value="{{ $listing->materialInfo->parking_spaces_count ?? '' }}">
                                </div>
                                <div class="col-span-2 space-y-2">
                                    <label class="block text-[10px] font-black text-slate-400 uppercase">Building
                                        Construction</label>
                                    <input type="text" name="construction_type"
                                        class="w-full rounded-xl border-slate-200 bg-white p-3 text-sm font-medium"
                                        placeholder="e.g. Standard Brick, Steel Frame..."
                                        value="{{ $listing->materialInfo->construction_type ?? '' }}">
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Utilities & Availability -->
                    <div class="p-8 bg-slate-900 rounded-[3rem] text-white shadow-2xl relative overflow-hidden group">
                        <div
                            class="absolute -right-20 -top-20 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl group-hover:bg-indigo-500/20 transition-all duration-700">
                        </div>

                        <h4
                            class="text-xs font-black text-indigo-300 uppercase tracking-widest flex items-center gap-3 mb-8 relative z-10">
                            <span
                                class="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center text-xl"><i
                                    class='bx bx-plug'></i></span>
                            Connectivity & Accessibility
                        </h4>

                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-12 gap-y-8 relative z-10">
                            <div class="space-y-3">
                                <label
                                    class="block text-[10px] font-black text-indigo-400 uppercase tracking-widest">Availability
                                    Date</label>
                                <div class="relative">
                                    <i
                                        class='bx bx-calendar absolute left-4 top-1/2 -translate-y-1/2 text-indigo-400 font-bold'></i>
                                    <input type="date" name="availability_date"
                                        class="w-full bg-white/10 border-white/10 rounded-2xl p-4 pl-12 text-sm font-bold text-white focus:ring-indigo-500/50"
                                        value="{{ $listing->availability_date ?? '' }}">
                                </div>
                            </div>

                            <div class="lg:col-span-2 grid grid-cols-2 md:grid-cols-3 gap-6">
                                <div class="space-y-2">
                                    <label class="block text-[9px] font-black text-slate-400 uppercase">Water Supply</label>
                                    <input type="text" name="utilities_water"
                                        class="w-full bg-white/5 border-white/5 rounded-xl p-3 text-xs"
                                        value="{{ $listing->utilities->water ?? '' }}">
                                </div>
                                <div class="space-y-2">
                                    <label class="block text-[9px] font-black text-slate-400 uppercase">Electricity</label>
                                    <input type="text" name="utilities_electricity"
                                        class="w-full bg-white/5 border-white/5 rounded-xl p-3 text-xs"
                                        value="{{ $listing->utilities->electricity ?? '' }}">
                                </div>
                                <div class="space-y-2">
                                    <label class="block text-[9px] font-black text-slate-400 uppercase">Broadband</label>
                                    <input type="text" name="utilities_broadband"
                                        class="w-full bg-white/5 border-white/5 rounded-xl p-3 text-xs"
                                        value="{{ $listing->utilities->broadband ?? '' }}">
                                </div>
                            </div>
                        </div>

                        <div class="mt-12 pt-8 border-t border-white/5 grid grid-cols-1 md:grid-cols-2 gap-8">
                            <div class="space-y-3">
                                <label
                                    class="block text-[10px] font-black text-emerald-400 uppercase tracking-widest">Government
                                    Incentives</label>
                                <input type="text" name="government_scheme"
                                    class="w-full bg-emerald-500/10 border-emerald-500/10 rounded-2xl p-4 text-sm font-bold text-emerald-50 text-white"
                                    placeholder="e.g. Help to Buy, Shared Ownership..."
                                    value="{{ $listing->details->government_scheme ?? '' }}">
                            </div>
                            <div class="space-y-3">
                                <label
                                    class="block text-[10px] font-black text-indigo-400 uppercase tracking-widest">Security
                                    Risks / Cladding</label>
                                <input type="text" name="cladding_risk"
                                    class="w-full bg-white/10 border-white/10 rounded-2xl p-4 text-sm font-bold text-white"
                                    placeholder="e.g. EWS1 Certified, Low Risk..."
                                    value="{{ $listing->materialInfo->cladding_risk ?? '' }}">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Step 3: Media Uploads -->
                <div id="stage3" class="hidden space-y-8 transition-all duration-500">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="p-4 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                            <label class="block text-xs font-bold text-slate-700 mb-3 flex items-center gap-2 italic">
                                <i class='bx bx-image-add text-lg text-[#02b8f2]'></i> HERO IMAGE (Required)
                            </label>
                            <input type="file" name="thumbnail" id="thumbnail" accept="image/*"
                                onchange="previewThumbnail(this)" class="hidden">
                            <label for="thumbnail"
                                class="w-full py-3 bg-white rounded-lg border border-slate-100 text-center cursor-pointer hover:shadow-md transition-all block text-[10px] font-bold text-[#02b8f2] uppercase">Click
                                to Upload</label>
                            <div id="thumbPreview"
                                class="mt-3 {{ isset($listing) && $listing->thumbnail ? '' : 'hidden' }}">
                                @if(isset($listing) && $listing->thumbnail)
                                    <div class="relative group w-full h-32">
                                        <img src="/storage/{{ $listing->thumbnail }}"
                                            class="w-full h-full object-cover rounded-lg shadow-lg">
                                        <button type="button" onclick="removeThumbnail()"
                                            class="absolute -top-2 -right-2 w-6 h-6 bg-rose-500 text-white rounded-full flex items-center justify-center">
                                            <i class='bx bx-x'></i>
                                        </button>
                                    </div>
                                @endif
                            </div>
                        </div>

                        <div class="p-4 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                            <label class="block text-xs font-bold text-slate-700 mb-3 flex items-center gap-2 italic">
                                <i class='bx bx-images text-lg text-[#02b8f2]'></i> PHOTOS
                            </label>
                            <input type="file" name="gallery[]" id="gallery" multiple accept="image/*"
                                onchange="handleGallerySelect(this)" class="hidden">
                            <label for="gallery"
                                class="w-full py-3 bg-white rounded-lg border border-slate-100 text-center cursor-pointer hover:shadow-md transition-all block text-[10px] font-bold text-[#02b8f2] uppercase">Select
                                Multiple</label>
                            <div id="galleryExisting" class="mt-3 flex flex-wrap gap-1.5">
                                @if(isset($listing) && $listing->media)
                                    @foreach($listing->media->where('type', 'photo') as $media)
                                        <div class="relative group existing-media-item">
                                            <img src="/storage/{{ $media->file_path }}"
                                                class="w-16 h-12 object-cover rounded-xl border border-slate-100 shadow-sm">
                                            <button type="button" onclick="removeExistingMedia({{ $media->id }}, this)"
                                                class="absolute -top-2 -right-2 w-5 h-5 bg-rose-500 text-white rounded-full flex items-center justify-center text-xs opacity-0 group-hover:opacity-100 transition-opacity">
                                                <i class='bx bx-x'></i>
                                            </button>
                                        </div>
                                    @endforeach
                                @endif
                            </div>
                            <div id="galleryNew" class="mt-1.5 flex flex-wrap gap-1.5"></div>
                        </div>
                    </div>

                    <div class="p-4 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                        <label class="block text-xs font-bold text-slate-700 mb-3 flex items-center gap-2 italic">
                            <i class='bx bx-map-alt text-lg text-[#02b8f2]'></i> FLOOR PLANS
                        </label>
                        <input type="file" name="floor_plans[]" id="floor_plans" multiple accept="image/*"
                            onchange="handleFloorPlansSelect(this)" class="hidden">
                        <label for="floor_plans"
                            class="w-full py-3 bg-white rounded-lg border border-slate-100 text-center cursor-pointer hover:shadow-md transition-all block text-[10px] font-bold text-[#02b8f2] uppercase">Upload
                            Floor Plans</label>
                        <div id="floorPlansExisting" class="mt-3 flex flex-wrap gap-1.5">
                            @if(isset($listing) && $listing->media)
                                @foreach($listing->media->where('type', 'floorplan') as $media)
                                    <div class="relative group existing-media-item">
                                        <img src="/storage/{{ $media->file_path }}"
                                            class="w-16 h-12 object-cover rounded-xl border border-slate-100 shadow-sm">
                                        <button type="button" onclick="removeExistingMedia({{ $media->id }}, this)"
                                            class="absolute -top-2 -right-2 w-5 h-5 bg-rose-500 text-white rounded-full flex items-center justify-center text-xs">
                                            <i class='bx bx-x'></i>
                                        </button>
                                    </div>
                                @endforeach
                            @endif
                        </div>
                        <div id="floorPlansNew" class="mt-1.5 flex flex-wrap gap-1.5"></div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="p-4 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                            <label class="block text-xs font-bold text-slate-700 mb-3 flex items-center gap-2 italic">
                                <i class='bx bx-certification text-lg text-emerald-500'></i> EPC UPLOAD
                            </label>
                            <input type="file" name="epc_upload" id="epc_upload" accept="image/*,application/pdf"
                                class="w-full text-xs text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:bg-emerald-50 file:text-emerald-700 file:font-bold hover:file:bg-emerald-100 cursor-pointer">
                            @if(isset($listing) && $listing->epc_upload)
                                <div class="mt-2 text-[10px] font-bold text-emerald-600 uppercase"><i class='bx bx-check'></i>
                                    EPC Uploaded</div>
                            @endif
                        </div>

                        <div class="p-4 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                            <label class="block text-xs font-bold text-slate-700 mb-3 flex items-center gap-2 italic">
                                <i class='bx bxs-file-pdf text-lg text-red-500'></i> BROCHURE (PDF)
                            </label>
                            <input type="file" name="brochure_pdf" id="brochure_pdf" accept="application/pdf"
                                class="w-full text-xs text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:bg-red-50 file:text-red-700 file:font-bold hover:file:bg-red-100 cursor-pointer">
                            @if(isset($listing) && $listing->brochure_pdf)
                                <div class="mt-2 text-[10px] font-bold text-red-600 uppercase"><i class='bx bx-check'></i>
                                    Brochure Uploaded</div>
                            @endif
                        </div>
                    </div>

                    <div class="p-6 bg-indigo-900 rounded-xl shadow-lg relative overflow-hidden">
                        <label class="block text-sm font-bold text-white mb-4 flex items-center gap-2 italic">
                            <i class='bx bxs-video text-2xl text-rose-400'></i> VIDEO WALKTHROUGH & VIRTUAL TOUR
                        </label>
                        <div class="space-y-4">
                            <div>
                                <label
                                    class="block text-[10px] font-bold text-indigo-300 uppercase tracking-widest mb-1">Video
                                    File</label>
                                <input type="file" name="video" id="video" accept="video/*"
                                    class="w-full text-xs text-indigo-200 file:mr-4 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:bg-white file:text-indigo-900 file:font-bold hover:file:bg-indigo-50 cursor-pointer">
                            </div>
                            <div>
                                <label
                                    class="block text-[10px] font-bold text-indigo-300 uppercase tracking-widest mb-1">Virtual
                                    Tour URL</label>
                                <input type="url" name="virtual_tour_url"
                                    class="w-full rounded-lg border-indigo-700 bg-indigo-800 text-white text-xs p-3 transition-all"
                                    placeholder="https://my.matterport.com/show/..."
                                    value="{{ $listing->virtual_tour_url ?? '' }}">
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="px-8 py-6 bg-slate-50/50 border-t border-slate-100 flex justify-between rounded-b-3xl">
                <button type="button" id="prevBtn" onclick="changeStep(-1)"
                    class="hidden px-8 py-3.5 rounded-2xl border-2 border-slate-100 bg-white text-slate-700 text-xs font-black uppercase tracking-widest hover:bg-slate-50 transition-all">Previous</button>
                <div class="flex-1 flex justify-end gap-3">
                    <a href="{{ route('admin.off-market-listings.index') }}"
                        class="px-6 py-3.5 text-slate-400 text-xs font-black uppercase tracking-widest hover:text-rose-500 transition-all flex items-center font-bold">Cancel</a>
                    <button type="button" id="draftBtn" onclick="saveAsDraft()"
                        class="px-12 py-3.5 rounded-2xl bg-amber-500 text-white text-xs font-black uppercase tracking-widest shadow-xl shadow-amber-100/30 active:scale-95 transition-all font-bold">Save
                        Draft</button>
                    <button type="button" id="nextBtn" onclick="changeStep(1)"
                        class="px-12 py-3.5 rounded-2xl bg-[#8046F1] text-white text-xs font-black uppercase tracking-widest shadow-xl shadow-purple-100/30 active:scale-95 transition-all font-bold">Next
                        Stage</button>
                    <button type="submit" id="submitBtn"
                        class="hidden px-12 py-3.5 rounded-2xl bg-[#131B31] text-white text-xs font-black uppercase tracking-widest shadow-xl shadow-slate-900/10 active:scale-95 transition-all font-bold">Publish
                        Deal</button>
                </div>
            </div>
        </form>
    </div>

    @push('scripts')
        <script async defer
            src="https://maps.googleapis.com/maps/api/js?key={{ config('services.google.maps_api_key') }}&libraries=places&callback=initAutocomplete"></script>
        <script>
            let autocomplete;
            let currentStep = 1;
            let editorInstance;
            const unitTypesData = @json($unitTypes);

            function initAutocomplete() {
                const input = document.getElementById("address");
                if (input && typeof google !== 'undefined' && google.maps && google.maps.places) {
                    const options = { componentRestrictions: { country: "gb" }, fields: ["geometry", "name"] };
                    autocomplete = new google.maps.places.Autocomplete(input, options);
                    autocomplete.addListener("place_changed", () => {
                        const p = autocomplete.getPlace();
                        if (p.geometry) {
                            $('#latitude').val(p.geometry.location.lat());
                            $('#longitude').val(p.geometry.location.lng());
                        }
                    });
                }
            }

            $(document).ready(function () {
                initSelect2();

                ClassicEditor.create(document.querySelector('#description_editor'), {
                    toolbar: [
                        'heading', '|',
                        'bold', 'italic', 'link', 'bulletedList', 'numberedList', 'blockQuote', '|',
                        'undo', 'redo'
                    ]
                }).then(editor => {
                    editorInstance = editor;
                    editor.model.document.on('change:data', () => {
                        $('#description_hidden').val(editor.getData());
                    });
                }).catch(error => console.error(error));

                // Attach change listeners
                $('#property_type_id').on('change', handleTypeChange);
                $('#unit_type_id').on('change', handleStrategyChange);

                // Initial setup
                const selectedUnitType = $('#unit_type_id').data('selected');
                handleTypeChange(selectedUnitType);
                handleStrategyChange();

                $('#listingForm').on('submit', function (e) {
                    e.preventDefault();
                    const formData = new FormData(this);
                    const url = @if(isset($listing)) "{{ route('admin.off-market-listings.update', $listing->id) }}" @else"{{ route('admin.off-market-listings.store') }}" @endif;

                    $.ajax({
                        url: url,
                        type: 'POST',
                        data: formData,
                        processData: false,
                        contentType: false,
                        success: function (res) {
                            if (res.success) {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Success',
                                    text: res.message,
                                    timer: 2000,
                                    showConfirmButton: false
                                }).then(() => {
                                    window.location.href = "{{ route('admin.off-market-listings.index') }}";
                                });
                            }
                        },
                        error: function (xhr) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: xhr.responseJSON?.message || 'Something went wrong'
                            });
                        }
                    });
                });
            });

            function initSelect2() {
                $('.select2').select2({ minimumResultsForSearch: Infinity });
            }

            function handleTypeChange(selectedId = null) {
                const id = $('#property_type_id').val();
                const validUnits = unitTypesData.filter(u => u.property_type_id == id);
                $('#unit_type_id').empty().append('<option value="">Choose Category</option>');
                validUnits.forEach(u => $('#unit_type_id').append(new Option(u.title, u.id, false, u.id == selectedId)));

                // Re-trigger strategy check when type changes
                handleStrategyChange();
            }

            function handleStrategyChange() {
                const title = ($('#unit_type_id option:selected').text() || "").toLowerCase();
                const isComm = title.includes('office') || title.includes('shop');

                if (isComm) {
                    $('#bedrooms_container, #bathrooms_container, #receptions_container').addClass('hidden');
                    $('#bedrooms, #bathrooms, #reception_rooms').val(0);
                } else {
                    $('#bedrooms_container, #bathrooms_container, #receptions_container').removeClass('hidden');
                }
            }

            function handlePurposeChange() {
                const p = $('#purpose').val();
                if (p === 'Rent') {
                    $('#rent_fields_container').removeClass('hidden');
                } else {
                    $('#rent_fields_container').addClass('hidden');
                }
            }

            function toggleLeaseholdFields() {
                const t = $('#tenure').val();
                if (t === 'Leasehold') {
                    $('#leasehold_fields').removeClass('hidden');
                } else {
                    $('#leasehold_fields').addClass('hidden');
                }
            }

            function addKeyFeature() {
                const container = $('#key_features_container');
                if (container.children().length >= 10) {
                    Swal.fire({ icon: 'warning', title: 'Limit Reached', text: 'Maximum 10 key features allowed' });
                    return;
                }
                const div = $(`
                                                                                            <div class="flex gap-2">
                                                                                                <input type="text" name="key_features[]" class="w-full rounded-lg border-slate-100 bg-slate-50/50 text-xs p-2" placeholder="Enter feature...">
                                                                                                <button type="button" onclick="this.parentElement.remove()" class="text-rose-500"><i class='bx bx-trash'></i></button>
                                                                                            </div>
                                                                                        `);
                container.append(div);
            }

            function removeExistingMedia(id, btn) {
                $('#listingForm').append(`<input type="hidden" name="remove_media[]" value="${id}">`);
                $(btn).closest('.existing-media-item').remove();
            }

            function changeStep(n) {
                if (n > 0) {
                    let v = true;
                    $(`#stage${currentStep} [required]`).each(function () {
                        const $el = $(this);
                        if ($el.is(':hidden') || $el.closest('.hidden').length > 0) return;
                        let val = $el.val();
                        if (!val || val === "" || val == null) {
                            $el.addClass('border-rose-400 ring-2 ring-rose-50');
                            if ($el.hasClass('select2-hidden-accessible')) {
                                $el.next('.select2-container').addClass('border-rose-400 ring-2 ring-rose-50');
                            }
                            v = false;
                        } else {
                            $el.removeClass('border-rose-400 ring-2 ring-rose-50');
                            if ($el.hasClass('select2-hidden-accessible')) {
                                $el.next('.select2-container').removeClass('border-rose-400 ring-2 ring-rose-50');
                            }
                        }
                    });
                    if (!v) {
                        Swal.mixin({ toast: true, position: 'top-end', showConfirmButton: false, timer: 3000 }).fire({ icon: 'error', title: 'Details Required', text: 'Please check marked fields' });
                        return;
                    }
                }

                currentStep += n;
                showStep(currentStep);
                // Scroll the main content area to top
                const mainEl = document.querySelector('main');
                if (mainEl) {
                    mainEl.scrollTo({ top: 0, behavior: 'smooth' });
                } else {
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                }
            }

            function showStep(n) {
                $('#stage1, #stage2, #stage3').addClass('hidden');
                $(`#stage${n}`).removeClass('hidden');

                $('#currentStepText').text(n);
                $('#stepLine').css('width', `${(n - 1) * 50}%`);

                for (let i = 1; i <= 3; i++) {
                    const circle = $(`#stepCircle${i}`);
                    const label = $(`#stepLabel${i}`);

                    circle.removeClass('step-circle-active step-circle-completed text-slate-400 border-slate-100 bg-white');
                    label.removeClass('text-indigo-600 text-slate-300 font-black').addClass('text-slate-300');

                    if (i < n) {
                        circle.addClass('step-circle-completed').html('<i class="bx bx-check text-xl"></i>').addClass('text-white bg-emerald-500 border-emerald-500');
                        label.addClass('text-emerald-500 font-bold');
                    } else if (i === n) {
                        circle.addClass('step-circle-active text-white bg-indigo-600 border-indigo-600').text(i);
                        label.addClass('text-indigo-600 font-black').removeClass('text-slate-300');
                    } else {
                        circle.addClass('text-slate-400 border-slate-100 bg-white').text(i);
                        label.addClass('text-slate-300');
                    }
                }

                $('#prevBtn').toggleClass('hidden', n === 1);
                $('#nextBtn').toggleClass('hidden', n === 3);
                $('#submitBtn').toggleClass('hidden', n !== 3);
                $('#draftBtn').toggleClass('hidden', n !== 1);
            }

            function saveAsDraft() {
                const formData = new FormData($('#listingForm')[0]);
                formData.append('is_draft', '1');
                const url = @if(isset($listing)) "{{ route('admin.off-market-listings.update', $listing->id) }}" @else"{{ route('admin.off-market-listings.store') }}" @endif;

                $.ajax({
                    url: url,
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function (res) {
                        Swal.fire({ icon: 'success', title: 'Draft Saved', text: res.message, timer: 2000, showConfirmButton: false })
                            .then(() => window.location.href = "{{ route('admin.off-market-listings.drafts') }}");
                    },
                    error: function (err) {
                        Swal.fire({ icon: 'error', title: 'Error', text: err.responseJSON?.message || 'Something went wrong' });
                    }
                });
            }

            const galleryDT = new DataTransfer();
            const floorPlansDT = new DataTransfer();

            function previewThumbnail(input) {
                const preview = $('#thumbPreview');
                if (input.files && input.files[0]) {
                    const reader = new FileReader();
                    reader.onload = function (e) {
                        preview.removeClass('hidden').html(`
                                                                                                    <div class="relative group w-full h-32">
                                                                                                        <img src="${e.target.result}" class="w-full h-full object-cover rounded-lg shadow-lg">
                                                                                                        <button type="button" onclick="removeThumbnail()" class="absolute -top-2 -right-2 w-6 h-6 bg-rose-500 text-white rounded-full flex items-center justify-center hover:bg-rose-600 transition-all shadow-md">
                                                                                                            <i class='bx bx-x'></i>
                                                                                                        </button>
                                                                                                    </div>
                                                                                                `);
                    }
                    reader.readAsDataURL(input.files[0]);
                }
            }

            function removeThumbnail() {
                if ($('#thumbPreview img').attr('src')?.includes('/storage/')) {
                    $('#listingForm').append('<input type="hidden" name="remove_thumbnail" value="1">');
                }
                $('#thumbnail').val('');
                $('#thumbPreview').addClass('hidden').html('');
            }

            function handleGallerySelect(input) {
                const files = input.files;
                for (let i = 0; i < files.length; i++) {
                    galleryDT.items.add(files[i]);
                }
                input.files = galleryDT.files;
                renderGalleryPreview();
            }

            function renderGalleryPreview() {
                const container = $('#galleryNew');
                container.empty();
                Array.from(galleryDT.files).forEach((file, index) => {
                    const reader = new FileReader();
                    reader.onload = function (e) {
                        const div = $(`
                                                                                                    <div class="relative group w-16 h-12">
                                                                                                        <img src="${e.target.result}" class="w-full h-full object-cover rounded-xl border border-slate-100 shadow-sm">
                                                                                                        <button type="button" onclick="removeGalleryFile(${index})" class="absolute -top-2 -right-2 w-5 h-5 bg-rose-500 text-white rounded-full flex items-center justify-center text-xs hover:bg-rose-600 transition-all shadow-md">
                                                                                                            <i class='bx bx-x'></i>
                                                                                                        </button>
                                                                                                    </div>
                                                                                                `);
                        container.append(div);
                    }
                    reader.readAsDataURL(file);
                });
            }

            function removeGalleryFile(index) {
                const dt = new DataTransfer();
                const files = galleryDT.files;
                for (let i = 0; i < files.length; i++) {
                    if (i !== index) dt.items.add(files[i]);
                }
                galleryDT.items.clear();
                for (let i = 0; i < dt.files.length; i++) galleryDT.items.add(dt.files[i]);
                document.getElementById('gallery').files = galleryDT.files;
                renderGalleryPreview();
            }

            function handleFloorPlansSelect(input) {
                const files = input.files;
                for (let i = 0; i < files.length; i++) {
                    floorPlansDT.items.add(files[i]);
                }
                input.files = floorPlansDT.files;
                renderFloorPlansPreview();
            }

            function renderFloorPlansPreview() {
                const container = $('#floorPlansNew');
                container.empty();
                Array.from(floorPlansDT.files).forEach((file, index) => {
                    const reader = new FileReader();
                    reader.onload = function (e) {
                        const div = $(`
                                                                                                    <div class="relative group w-16 h-12">
                                                                                                        <img src="${e.target.result}" class="w-full h-full object-cover rounded-xl border border-slate-100 shadow-sm">
                                                                                                        <button type="button" onclick="removeFloorPlanFile(${index})" class="absolute -top-2 -right-2 w-5 h-5 bg-rose-500 text-white rounded-full flex items-center justify-center text-xs hover:bg-rose-600 transition-all shadow-md">
                                                                                                            <i class='bx bx-x'></i>
                                                                                                        </button>
                                                                                                    </div>
                                                                                                `);
                        container.append(div);
                    }
                    reader.readAsDataURL(file);
                });
            }

            function removeFloorPlanFile(index) {
                const dt = new DataTransfer();
                const files = floorPlansDT.files;
                for (let i = 0; i < files.length; i++) {
                    if (i !== index) dt.items.add(files[i]);
                }
                floorPlansDT.items.clear();
                for (let i = 0; i < dt.files.length; i++) floorPlansDT.items.add(dt.files[i]);
                document.getElementById('floor_plans').files = floorPlansDT.files;
                renderFloorPlansPreview();
            }
        </script>
    @endpush
@endsection